package com.cg.jdbc.DAO;

import com.cg.jdbc.entity.Account;
import com.cg.jdbc.entity.Customer;
import com.cg.jdbc.excepton.BankPW_Exception;

public interface BankPW_DAO {
	public String createAccount(Account account, Customer customer)throws BankPW_Exception;
	public Account showBalance(String accountNo)throws BankPW_Exception;
	public Account deposite(String accountNo, double amount)throws BankPW_Exception;
	public Account withDraw(String accountNo, double amount)throws BankPW_Exception;
	public Account fundTransfer(String accountNo,String accountNo1, double amount) throws BankPW_Exception;

}
