package com.cg.ac.service;

import java.util.List;

import com.cg.ac.entity.Account;



public interface AccountService {
	public abstract Account save(Account account);
	public abstract List<Account> loadAll();
	public Account showBalance(int accountNo);
	public Account deposite(int accountNo, int amount);
	public Account withDraw(int accountNo, int amount);
	public Account fundTransfer(int accountNo,int accountNo1, int amount);
}
