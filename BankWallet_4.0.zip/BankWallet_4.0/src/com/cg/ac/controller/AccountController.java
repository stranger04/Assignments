package com.cg.ac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.ac.entity.Account;
import com.cg.ac.service.AccountService;



@Controller
public class AccountController {
	@Autowired
	private AccountService accountService;
	@RequestMapping("/index")
	public String getHomePage(Model model)
	{
		model.addAttribute("accountList", accountService.loadAll());
		model.addAttribute("accountType",new String[]
				{"Current","Savings","Other"}
				);
		model.addAttribute("account", new Account());
		return "index";
	}
@RequestMapping(value="/save",method=RequestMethod.POST)
	
	public String saveAccount(@ModelAttribute("account") Account account,Model model)
	{
		account =  accountService.save(account);
	
		model.addAttribute("message","Account No: "+account.getAccountNo()+"added Successfully");
		return "redirect:/index.html";
	}
public Account showBalance(@ModelAttribute("account") Account account,Model model,int accountNo) 
{
	account =  accountService.showBalance(accountNo);
	return null;
	
}
public Account deposite(@ModelAttribute("account") Account account,Model model,int accountNo, int amount)
{
	accountService.deposite(accountNo, amount);
	return null;
	
}
public Account withDraw(@ModelAttribute("account") Account account,Model model,int accountNo, int amount)
{
	accountService.withDraw(accountNo, amount);
	return null;
	
}
public Account fundTransfer(@ModelAttribute("account") Account account,Model model,int accountNo,int accountNo1, int amount)
{
	accountService.fundTransfer(accountNo, accountNo1, amount);
	return null;
	
}

}
