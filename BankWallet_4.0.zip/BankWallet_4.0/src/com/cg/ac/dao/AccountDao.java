package com.cg.ac.dao;

import java.util.List;

import com.cg.ac.entity.Account;

public interface AccountDao {
	public abstract Account save(Account account);
	public abstract List<Account> loadAll();
	public Account showBalance(int accountNo);
	public Account deposite(int accountNo, int amount);
	public Account withDraw(int accountNo, int amount);
	public Account fundTransfer(int accountNo,int accountNo1, int amount);

}
