package com.cg.ac.entity;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer implements Serializable{
	@Column(name = "Name",length = 20)
	private String name;
	@Column(name = "PAN_No",length = 10)
	private String panNo;
	@Column(name = "Aadhar_No",length = 18)
	private String aadharNo;
	@Id
	@Column(name = "Account_No",length = 12)
	private String accountNo;
	@Column(name = "Contact",length = 10)
	private String contact;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String name, String panNo, String aadharNo, String accountNo, String contact) {
		super();
		this.name = name;
		this.panNo = panNo;
		this.aadharNo = aadharNo;
		this.accountNo = accountNo;
		this.contact = contact;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", panNo=" + panNo + ", aadharNo=" + aadharNo + ", accountNo=" + accountNo
				+ ", contact=" + contact + "]";
	}
	
	

}
