package POM;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class pomclass
{
	WebDriver driver;
	   @FindBy(how = How.XPATH,using="//*[@id=\"fname\"]") 
	   public static WebElement firstname;
	  
	   
	   @FindBy(how = How.XPATH,using="//*[@id='lname']") 
	   WebElement lastname;
	   @FindBy(how = How.XPATH,using="//*[@id=\"emails\"]") 
	   WebElement email;
	   @FindBy(how = How.XPATH,using="//*[@id='mobile']") 
	   WebElement mobile;
	   @FindBy(how = How.XPATH,using="//*[@id='enqdetails']") 
	   WebElement enquiry;
	   @FindBy(how = How.NAME,using="D5") 
	   WebElement city;
	   @FindBy(how = How.NAME,using="D4") 
	   WebElement mode;
	   @FindBy(how = How.NAME,using="D6") 
	   WebElement tutiontype;
	   
	   @FindBy(how = How.XPATH,using="//*[@id=\"Submit1\"]") 
	   WebElement button;
	   public pomclass(WebDriver driver)
	   {
	       this.driver = driver;
	        PageFactory.initElements(driver, this);
	      // driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	   }
	    
	     public void firstname(String n)
	     {
	    	 firstname.sendKeys(n);
	     }
	     
	     public void lastname(String n)
	     {
	    	 lastname.sendKeys(n);
	     }
	     
	     public void email1(String email1)
	     {
	         email.sendKeys(email1);
	     }
	     public void mobile1(String mobile1)
	     {
	    	 mobile.sendKeys(mobile1);
	     }     
	     public void tutiontype(String tutiontype1)
	     {
	    	 Select s1=new Select(tutiontype);
             s1.selectByVisibleText(tutiontype1);	    
         }   
	     public void city(String city1)
	     {
	    	 Select s2=new Select(city);
             s2.selectByVisibleText(city1);
 	     }     
	     public void mode(String mode1)
	     {
	    	 Select s3=new Select(mode);
             s3.selectByVisibleText(mode1);
	    	 
 	     }
	     public void enquiry1(String t)
	     {
	         enquiry.sendKeys(t);
	     }
	     
	     public void clickloginbutton()
	     {
	    	 button.submit();
	     }
	   
	   
   
}
