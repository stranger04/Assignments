package com.cg.ParallelProject.enity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity(name="Account_Boot")
public class Account {
	@Id
	@Column(name = "Account_No",length = 12)
	private int accountNo;
	@Column(name = "Name",length = 20)
	private String name;
	@Column(name = "Balance",length = 20)
	private int balance;
	@Column(name = "Contact",length = 10)
	private String contactNo;
	@Column(name = "Account",length = 20)
	private String accountType;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(int accountNo, String name, int balance, String contactNo, String accountType) {
		super();
		this.accountNo = accountNo;
		this.name = name;
		this.balance = balance;
		this.contactNo = contactNo;
		this.accountType = accountType;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", name=" + name + ", balance=" + balance + ", contactNo="
				+ contactNo + ", accountType=" + accountType + "]";
	}
	
	

}
